<!DOCTYPE html>
<html>
<head>
    <title>Book Management</title>
</head>
<body>
    <h1>All Books</h1>
    <ul>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($book->title); ?> - ISBN: <?php echo e($book->ISBN); ?> - Publication Year: <?php echo e($book->pub_year); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h1>Search Books By Name</h1>
    <form action="<?php echo e(route('books.search')); ?>" method="GET">
        <input type="text" name="search" value="<?php echo e($searchTerm ?? ''); ?>" placeholder="Enter book name">
        <button type="submit">Search</button>
    </form>
</body>
</html>
<?php /**PATH C:\BookManagement\resources\views/books/index.blade.php ENDPATH**/ ?>